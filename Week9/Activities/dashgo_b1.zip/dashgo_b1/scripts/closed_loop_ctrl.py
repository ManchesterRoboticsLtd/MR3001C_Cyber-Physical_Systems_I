#!/usr/bin/env python
import rospy
import numpy as np
from std_msgs.msg import Float32
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist, Pose, PoseStamped
import tf2_ros
import tf2_geometry_msgs
import tf_conversions

# Setup Variables to be used
first = True
start_time = 0.0
current_time = 0.0
last_time = 0.0
Error = 0.0
Error_int = 0.0

Error_pos = np.zeros([2])
E_d = 0.0
E_th = 0.0
E_d_int = 0.0
E_th_int = 0.0
control_Omega  = 0.0
control_V = 0.0

# Setup the input/output Messages
controlOutput = Twist()
robot_odom = Odometry()
goal = None
goal_tf = None


#Define the callback functions
def odom_callback(msg):
    global robot_odom
    robot_odom = msg

def goal_callback(msg):
    global goal
    goal = msg
    

#wrap to pi function
def wrap_to_Pi(theta):
    result = np.fmod((theta + np.pi),(2 * np.pi))
    if(result < 0):
      result += 2 * np.pi
    return result - np.pi

#Stop Condition
def stop():
  #Setup the stop message (can be the same as the control message)
    controlOutput.linear.x = 0.0
    controlOutput.linear.y = 0.0
    controlOutput.linear.z = 0.0
    controlOutput.angular.x = 0.0
    controlOutput.angular.y = 0.0
    controlOutput.angular.z = 0.0

    control_pub.publish(controlOutput)
    total_time = rospy.get_time()- start_time
    print("Stopping", " ", "Total Time", "  ", total_time)

if __name__=='__main__':

    #Initialise and Setup node
    rospy.init_node("Position_Control")

    #Set the parameters of the Controller Node

    #Controller Gains
    _v_gains = rospy.get_param("~v_gains",{'p': 0.09, 'i': 0.0})
    _w_gains= rospy.get_param("~w_gains",{'p': 0.3, 'i': 0.0})

    #Radius around the goal
    _goal_radius = rospy.get_param("~goal_radius",0.2)

    #Node Parameters
    _sample_time = rospy.get_param("~sample_time",0.02)
    _node_rate = rospy.get_param("~node_rate",100)

    #Node Parameters

    #Goal and base frames 
    _target_link = rospy.get_param("~base_frame", "base_link")
    _source_link = rospy.get_param("~goal_frame", "world")

    # Configure the Node
    loop_rate = rospy.Rate(_node_rate)
    rospy.on_shutdown(stop)


    #Setup de publishers
    control_pub = rospy.Publisher("cmd_vel", Twist, queue_size=1)
    
    # Setup the Subscribers
    rospy.Subscriber("odom",Odometry, odom_callback)
    rospy.Subscriber("goal", PoseStamped, goal_callback)

    #   Setup the Subscribers
    tfBuffer = tf2_ros.Buffer()
    listener = tf2_ros.TransformListener(tfBuffer)

    print("The Control is Running")    

    try:
        while not rospy.is_shutdown():
              
            if first == True:
                start_time = rospy.get_time() 
                last_time = rospy.get_time()
                current_time = rospy.get_time()
                first = False
            
            else:
                current_time = rospy.get_time()
                dt = current_time - last_time

                if dt >= _sample_time:
                    try:
                        trans = tfBuffer.lookup_transform(_target_link , _source_link, rospy.Time())
                    except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
                        loop_rate.sleep()
                        continue
                    
                    if goal == None:
                        loop_rate.sleep()

                    else:
                        goal_tf = tf2_geometry_msgs.do_transform_pose(goal,trans)
                        Error_pos[0] = goal_tf.pose.position.x
                        Error_pos[1] = goal_tf.pose.position.y

                        E_d = np.sqrt(np.dot(Error_pos,Error_pos.T))

                        E_th = np.arctan2(Error_pos[1],Error_pos[0])

                        E_th = wrap_to_Pi(E_th)

                        if E_d < _goal_radius:
                            control_V= 0.0
                            control_Omega=0.0
                        
                        else:
                            E_d_int += (E_d) * dt
                            E_th_int += (E_th) * dt

                            control_V = _v_gains['p'] * E_d + _v_gains['i'] * E_d_int
                            control_Omega = _w_gains['p'] * E_th + _w_gains['i'] * E_th_int

                        last_time = rospy.get_time()

                        controlOutput.linear.x = control_V 
                        controlOutput.linear.y = 0.0
                        controlOutput.linear.z = 0.0
                        controlOutput.angular.x = 0.0
                        controlOutput.angular.y = 0.0
                        controlOutput.angular.z = control_Omega

                    
                        control_pub.publish(controlOutput)



            loop_rate.sleep()
 
    except rospy.ROSInterruptException:
        pass