#!/usr/bin/env python3
import rospy
from visualization_msgs.msg import Marker
import tf_conversions

def make_marker(frame, ns, ident, mtype, pos, scale, color, q=None):
    m = Marker()
    m.header.frame_id = frame
    m.header.stamp = rospy.Time.now()
    m.ns = ns
    m.id = ident
    m.type = mtype
    m.action = Marker.ADD
    m.pose.position.x, m.pose.position.y, m.pose.position.z = pos
    if q is None:
        m.pose.orientation.w = 1.0
    else:
        m.pose.orientation.x, m.pose.orientation.y, m.pose.orientation.z, m.pose.orientation.w = q
    m.scale.x, m.scale.y, m.scale.z = scale
    m.color.r, m.color.g, m.color.b, m.color.a = color
    m.lifetime = rospy.Duration(0)
    return m

def main():
    rospy.init_node('robot_markers')
    pub = rospy.Publisher('/robot_visualization', Marker, queue_size=10)
    rospy.sleep(0.3)

    q_wheel = tf_conversions.transformations.quaternion_from_euler(1.5708, 0.0, 0.0)  # rueda acostada

    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        # chasis en frame 'chassis'
        pub.publish(make_marker('chassis','robot',0, Marker.CUBE,    [0,0,0], [0.36,0.26,0.12],[0.0,0.6,1.0,1.0]))
        # ruedas en frames 'wheel_l' y 'wheel_r'
        pub.publish(make_marker('wheel_l','robot',1, Marker.CYLINDER,[0,0,0], [0.14,0.14,0.04],[0.2,0.2,0.2,1.0], q_wheel))
        pub.publish(make_marker('wheel_r','robot',2, Marker.CYLINDER,[0,0,0], [0.14,0.14,0.04],[0.2,0.2,0.2,1.0], q_wheel))
        # caster en frame 'caster'
        pub.publish(make_marker('caster', 'robot',3, Marker.SPHERE,  [0,0,0], [0.06,0.06,0.06],[0.8,0.8,0.0,1.0]))
        rate.sleep()

if __name__ == '__main__':
    main()
